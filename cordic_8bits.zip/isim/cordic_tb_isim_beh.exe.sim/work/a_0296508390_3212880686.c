/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *STD_STANDARD;
extern char *IEEE_P_3499444699;
static const char *ng2 = "Function addsub ended without a return statement";
static const char *ng3 = "D:/ise/ise_crack/code/cordic_8bits/cordicPipe.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1690584930_503743352(char *, unsigned char );
char *ieee_p_3499444699_sub_3158760445_3536714472(char *, char *, char *, char *, char *, char *);
char *ieee_p_3499444699_sub_3158832319_3536714472(char *, char *, char *, char *, char *, char *);


int work_a_0296508390_3212880686_sub_1303446750_3057020925(char *t1, int t2)
{
    char t3[128];
    char t4[8];
    char t8[8];
    int t0;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    int t14;

LAB0:    t5 = (t3 + 4U);
    t6 = ((STD_STANDARD) + 384);
    t7 = (t5 + 88U);
    *((char **)t7) = t6;
    t9 = (t5 + 56U);
    *((char **)t9) = t8;
    xsi_type_set_default_value(t6, t8, 0);
    t10 = (t5 + 80U);
    *((unsigned int *)t10) = 4U;
    t11 = (t4 + 4U);
    *((int *)t11) = t2;
    if (t2 == 0)
        goto LAB3;

LAB14:    if (t2 == 1)
        goto LAB4;

LAB15:    if (t2 == 2)
        goto LAB5;

LAB16:    if (t2 == 3)
        goto LAB6;

LAB17:    if (t2 == 4)
        goto LAB7;

LAB18:    if (t2 == 5)
        goto LAB8;

LAB19:    if (t2 == 6)
        goto LAB9;

LAB20:    if (t2 == 7)
        goto LAB10;

LAB21:    if (t2 == 8)
        goto LAB11;

LAB22:    if (t2 == 9)
        goto LAB12;

LAB23:
LAB13:    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    *((int *)t6) = 0;

LAB2:    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t14 = *((int *)t7);
    t0 = t14;

LAB1:    return t0;
LAB3:    t12 = (t5 + 56U);
    t13 = *((char **)t12);
    t12 = (t13 + 0);
    *((int *)t12) = 512;
    goto LAB2;

LAB4:    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    *((int *)t6) = 302;
    goto LAB2;

LAB5:    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    *((int *)t6) = 159;
    goto LAB2;

LAB6:    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    *((int *)t6) = 81;
    goto LAB2;

LAB7:    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    *((int *)t6) = 40;
    goto LAB2;

LAB8:    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    *((int *)t6) = 20;
    goto LAB2;

LAB9:    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    *((int *)t6) = 10;
    goto LAB2;

LAB10:    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    *((int *)t6) = 5;
    goto LAB2;

LAB11:    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    *((int *)t6) = 2;
    goto LAB2;

LAB12:    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t6 = (t7 + 0);
    *((int *)t6) = 1;
    goto LAB2;

LAB24:;
LAB25:;
}

char *work_a_0296508390_3212880686_sub_3176558394_3057020925(char *t1, char *t2, char *t3, char *t4, int t5)
{
    char t6[248];
    char t7[24];
    char t10[16];
    char t39[8];
    char *t0;
    char *t8;
    unsigned int t9;
    char *t11;
    int t12;
    char *t13;
    int t14;
    char *t15;
    int t16;
    char *t17;
    char *t18;
    int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    int t27;
    char *t28;
    int t29;
    char *t30;
    int t31;
    char *t32;
    int t33;
    int t34;
    int t35;
    char *t36;
    char *t37;
    char *t38;
    char *t40;
    char *t41;
    char *t42;
    unsigned char t43;
    char *t44;
    char *t45;
    char *t46;
    char *t47;
    int t48;
    int t49;
    int t50;
    char *t51;
    int t52;
    char *t53;
    int t54;
    int t55;
    int t56;
    int t57;
    char *t58;
    int t59;
    char *t60;
    int t61;
    char *t62;
    int t63;
    char *t64;
    int t65;
    char *t66;
    int t67;
    int t68;
    unsigned int t69;
    unsigned int t70;
    char *t71;
    unsigned char t72;
    char *t73;
    char *t74;
    int t75;
    char *t76;
    int t77;
    int t78;
    unsigned int t79;
    char *t80;
    int t81;
    unsigned int t82;
    unsigned int t83;
    char *t84;

LAB0:    t8 = (t4 + 12U);
    t9 = *((unsigned int *)t8);
    t9 = (t9 * 1U);
    t11 = (t4 + 0U);
    t12 = *((int *)t11);
    t13 = (t4 + 4U);
    t14 = *((int *)t13);
    t15 = (t4 + 8U);
    t16 = *((int *)t15);
    t17 = (t10 + 0U);
    t18 = (t17 + 0U);
    *((int *)t18) = t12;
    t18 = (t17 + 4U);
    *((int *)t18) = t14;
    t18 = (t17 + 8U);
    *((int *)t18) = t16;
    t19 = (t14 - t12);
    t20 = (t19 * t16);
    t20 = (t20 + 1);
    t18 = (t17 + 12U);
    *((unsigned int *)t18) = t20;
    t18 = (t6 + 4U);
    t21 = ((IEEE_P_3499444699) + 2728);
    t22 = (t18 + 88U);
    *((char **)t22) = t21;
    t23 = (char *)alloca(t9);
    t24 = (t18 + 56U);
    *((char **)t24) = t23;
    xsi_type_set_default_value(t21, t23, t10);
    t25 = (t18 + 64U);
    *((char **)t25) = t10;
    t26 = (t18 + 80U);
    *((unsigned int *)t26) = t9;
    t28 = (t4 + 0U);
    t29 = *((int *)t28);
    t30 = (t4 + 4U);
    t31 = *((int *)t30);
    t32 = (t4 + 8U);
    t33 = *((int *)t32);
    if (t29 > t31)
        goto LAB2;

LAB3:    if (t33 == -1)
        goto LAB7;

LAB8:    t27 = t31;

LAB4:    t34 = (t27 - t5);
    t35 = (t34 + 1);
    t36 = (t6 + 124U);
    t37 = ((STD_STANDARD) + 384);
    t38 = (t36 + 88U);
    *((char **)t38) = t37;
    t40 = (t36 + 56U);
    *((char **)t40) = t39;
    *((int *)t39) = t35;
    t41 = (t36 + 80U);
    *((unsigned int *)t41) = 4U;
    t42 = (t7 + 4U);
    t43 = (t3 != 0);
    if (t43 == 1)
        goto LAB10;

LAB9:    t44 = (t7 + 12U);
    *((char **)t44) = t4;
    t45 = (t7 + 20U);
    *((int *)t45) = t5;
    t46 = (t36 + 56U);
    t47 = *((char **)t46);
    t48 = *((int *)t47);
    t46 = (t4 + 0U);
    t50 = *((int *)t46);
    t51 = (t4 + 4U);
    t52 = *((int *)t51);
    t53 = (t4 + 8U);
    t54 = *((int *)t53);
    if (t50 > t52)
        goto LAB15;

LAB16:    if (t54 == -1)
        goto LAB20;

LAB21:    t49 = t52;

LAB17:    t55 = t49;
    t56 = t48;

LAB11:    if (t55 >= t56)
        goto LAB12;

LAB14:    t8 = (t4 + 0U);
    t14 = *((int *)t8);
    t11 = (t4 + 4U);
    t16 = *((int *)t11);
    t13 = (t4 + 8U);
    t19 = *((int *)t13);
    if (t14 > t16)
        goto LAB34;

LAB35:    if (t19 == -1)
        goto LAB39;

LAB40:    t12 = t16;

LAB36:    t27 = (t12 - t5);
    t29 = t27;
    t31 = 0;

LAB30:    if (t29 >= t31)
        goto LAB31;

LAB33:    t8 = (t18 + 56U);
    t11 = *((char **)t8);
    t8 = (t10 + 12U);
    t9 = *((unsigned int *)t8);
    t9 = (t9 * 1U);
    t0 = xsi_get_transient_memory(t9);
    memcpy(t0, t11, t9);
    t13 = (t10 + 0U);
    t12 = *((int *)t13);
    t15 = (t10 + 4U);
    t14 = *((int *)t15);
    t17 = (t10 + 8U);
    t16 = *((int *)t17);
    t21 = (t2 + 0U);
    t22 = (t21 + 0U);
    *((int *)t22) = t12;
    t22 = (t21 + 4U);
    *((int *)t22) = t14;
    t22 = (t21 + 8U);
    *((int *)t22) = t16;
    t19 = (t14 - t12);
    t20 = (t19 * t16);
    t20 = (t20 + 1);
    t22 = (t21 + 12U);
    *((unsigned int *)t22) = t20;

LAB1:    return t0;
LAB2:    if (t33 == 1)
        goto LAB5;

LAB6:    t27 = t29;
    goto LAB4;

LAB5:    t27 = t31;
    goto LAB4;

LAB7:    t27 = t29;
    goto LAB4;

LAB10:    *((char **)t42) = t3;
    goto LAB9;

LAB12:    t58 = (t4 + 0U);
    t59 = *((int *)t58);
    t60 = (t4 + 4U);
    t61 = *((int *)t60);
    t62 = (t4 + 8U);
    t63 = *((int *)t62);
    if (t59 > t61)
        goto LAB22;

LAB23:    if (t63 == -1)
        goto LAB27;

LAB28:    t57 = t61;

LAB24:    t64 = (t4 + 0U);
    t65 = *((int *)t64);
    t66 = (t4 + 8U);
    t67 = *((int *)t66);
    t68 = (t57 - t65);
    t20 = (t68 * t67);
    t69 = (1U * t20);
    t70 = (0 + t69);
    t71 = (t3 + t70);
    t72 = *((unsigned char *)t71);
    t73 = (t18 + 56U);
    t74 = *((char **)t73);
    t73 = (t10 + 0U);
    t75 = *((int *)t73);
    t76 = (t10 + 8U);
    t77 = *((int *)t76);
    t78 = (t55 - t75);
    t79 = (t78 * t77);
    t80 = (t10 + 4U);
    t81 = *((int *)t80);
    xsi_vhdl_check_range_of_index(t75, t81, t77, t55);
    t82 = (1U * t79);
    t83 = (0 + t82);
    t84 = (t74 + t83);
    *((unsigned char *)t84) = t72;

LAB13:    if (t55 == t56)
        goto LAB14;

LAB29:    t12 = (t55 + -1);
    t55 = t12;
    goto LAB11;

LAB15:    if (t54 == 1)
        goto LAB18;

LAB19:    t49 = t50;
    goto LAB17;

LAB18:    t49 = t52;
    goto LAB17;

LAB20:    t49 = t50;
    goto LAB17;

LAB22:    if (t63 == 1)
        goto LAB25;

LAB26:    t57 = t59;
    goto LAB24;

LAB25:    t57 = t61;
    goto LAB24;

LAB27:    t57 = t59;
    goto LAB24;

LAB31:    t33 = (t29 + t5);
    t15 = (t4 + 0U);
    t34 = *((int *)t15);
    t17 = (t4 + 8U);
    t35 = *((int *)t17);
    t48 = (t33 - t34);
    t9 = (t48 * t35);
    t21 = (t4 + 4U);
    t49 = *((int *)t21);
    xsi_vhdl_check_range_of_index(t34, t49, t35, t33);
    t20 = (1U * t9);
    t69 = (0 + t20);
    t22 = (t3 + t69);
    t43 = *((unsigned char *)t22);
    t24 = (t18 + 56U);
    t25 = *((char **)t24);
    t24 = (t10 + 0U);
    t50 = *((int *)t24);
    t26 = (t10 + 8U);
    t52 = *((int *)t26);
    t54 = (t29 - t50);
    t70 = (t54 * t52);
    t28 = (t10 + 4U);
    t55 = *((int *)t28);
    xsi_vhdl_check_range_of_index(t50, t55, t52, t29);
    t79 = (1U * t70);
    t82 = (0 + t79);
    t30 = (t25 + t82);
    *((unsigned char *)t30) = t43;

LAB32:    if (t29 == t31)
        goto LAB33;

LAB41:    t12 = (t29 + -1);
    t29 = t12;
    goto LAB30;

LAB34:    if (t19 == 1)
        goto LAB37;

LAB38:    t12 = t14;
    goto LAB36;

LAB37:    t12 = t16;
    goto LAB36;

LAB39:    t12 = t14;
    goto LAB36;

LAB42:;
}

char *work_a_0296508390_3212880686_sub_3455323766_3057020925(char *t1, char *t2, char *t3, char *t4, char *t5, char *t6, unsigned char t7)
{
    char t9[40];
    char t18[16];
    char *t0;
    char *t10;
    unsigned char t11;
    char *t12;
    char *t13;
    unsigned char t14;
    char *t15;
    char *t16;
    unsigned char t17;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    int t24;
    char *t25;
    int t26;
    char *t27;
    int t28;
    char *t29;
    char *t30;
    int t31;
    unsigned int t32;

LAB0:    t10 = (t9 + 4U);
    t11 = (t3 != 0);
    if (t11 == 1)
        goto LAB3;

LAB2:    t12 = (t9 + 12U);
    *((char **)t12) = t4;
    t13 = (t9 + 20U);
    t14 = (t5 != 0);
    if (t14 == 1)
        goto LAB5;

LAB4:    t15 = (t9 + 28U);
    *((char **)t15) = t6;
    t16 = (t9 + 36U);
    *((unsigned char *)t16) = t7;
    t17 = (t7 == (unsigned char)3);
    if (t17 != 0)
        goto LAB6;

LAB8:    t19 = ieee_p_3499444699_sub_3158832319_3536714472(IEEE_P_3499444699, t18, t3, t4, t5, t6);
    t20 = (t18 + 12U);
    t21 = *((unsigned int *)t20);
    t22 = (1U * t21);
    t0 = xsi_get_transient_memory(t22);
    memcpy(t0, t19, t22);
    t23 = (t18 + 0U);
    t24 = *((int *)t23);
    t25 = (t18 + 4U);
    t26 = *((int *)t25);
    t27 = (t18 + 8U);
    t28 = *((int *)t27);
    t29 = (t2 + 0U);
    t30 = (t29 + 0U);
    *((int *)t30) = t24;
    t30 = (t29 + 4U);
    *((int *)t30) = t26;
    t30 = (t29 + 8U);
    *((int *)t30) = t28;
    t31 = (t26 - t24);
    t32 = (t31 * t28);
    t32 = (t32 + 1);
    t30 = (t29 + 12U);
    *((unsigned int *)t30) = t32;

LAB1:    return t0;
LAB3:    *((char **)t10) = t3;
    goto LAB2;

LAB5:    *((char **)t13) = t5;
    goto LAB4;

LAB6:    t19 = ieee_p_3499444699_sub_3158760445_3536714472(IEEE_P_3499444699, t18, t3, t4, t5, t6);
    t20 = (t18 + 12U);
    t21 = *((unsigned int *)t20);
    t22 = (1U * t21);
    t0 = xsi_get_transient_memory(t22);
    memcpy(t0, t19, t22);
    t23 = (t18 + 0U);
    t24 = *((int *)t23);
    t25 = (t18 + 4U);
    t26 = *((int *)t25);
    t27 = (t18 + 8U);
    t28 = *((int *)t27);
    t29 = (t2 + 0U);
    t30 = (t29 + 0U);
    *((int *)t30) = t24;
    t30 = (t29 + 4U);
    *((int *)t30) = t26;
    t30 = (t29 + 8U);
    *((int *)t30) = t28;
    t31 = (t26 - t24);
    t32 = (t31 * t28);
    t32 = (t32 + 1);
    t30 = (t29 + 12U);
    *((unsigned int *)t30) = t32;
    goto LAB1;

LAB7:    xsi_error(ng2);
    t0 = 0;
    goto LAB1;

LAB9:    goto LAB7;

LAB10:    goto LAB7;

}

static void work_a_0296508390_3212880686_p_0(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(110, ng3);

LAB3:    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t2 = (t0 + 10872U);
    t4 = work_a_0296508390_3212880686_sub_3176558394_3057020925(t0, t1, t3, t2, 0);
    t5 = (t1 + 12U);
    t6 = *((unsigned int *)t5);
    t6 = (t6 * 1U);
    t7 = (8U != t6);
    if (t7 == 1)
        goto LAB5;

LAB6:    t8 = (t0 + 7328);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t4, 8U);
    xsi_driver_first_trans_fast(t8);

LAB2:    t13 = (t0 + 7136);
    *((int *)t13) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(8U, t6, 0);
    goto LAB6;

}

static void work_a_0296508390_3212880686_p_1(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(111, ng3);

LAB3:    t2 = (t0 + 1512U);
    t3 = *((char **)t2);
    t2 = (t0 + 10888U);
    t4 = work_a_0296508390_3212880686_sub_3176558394_3057020925(t0, t1, t3, t2, 0);
    t5 = (t1 + 12U);
    t6 = *((unsigned int *)t5);
    t6 = (t6 * 1U);
    t7 = (8U != t6);
    if (t7 == 1)
        goto LAB5;

LAB6:    t8 = (t0 + 7392);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t4, 8U);
    xsi_driver_first_trans_fast(t8);

LAB2:    t13 = (t0 + 7152);
    *((int *)t13) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(8U, t6, 0);
    goto LAB6;

}

static void work_a_0296508390_3212880686_p_2(char *t0)
{
    char t1[16];
    int t2;
    char *t3;
    char *t4;
    unsigned int t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    xsi_set_current_line(112, ng3);

LAB3:    t2 = work_a_0296508390_3212880686_sub_1303446750_3057020925(t0, 0);
    t3 = ieee_std_logic_arith_conv_signed_integer(IEEE_P_3499444699, t1, t2, 12);
    t4 = (t1 + 12U);
    t5 = *((unsigned int *)t4);
    t5 = (t5 * 1U);
    t6 = (12U != t5);
    if (t6 == 1)
        goto LAB5;

LAB6:    t7 = (t0 + 7456);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t3, 12U);
    xsi_driver_first_trans_fast(t7);

LAB2:
LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(12U, t5, 0);
    goto LAB6;

}

static void work_a_0296508390_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;

LAB0:    xsi_set_current_line(114, ng3);

LAB3:    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t3 = (11 - 11);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = (t0 + 7520);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    *((unsigned char *)t12) = t7;
    xsi_driver_first_trans_fast(t8);

LAB2:    t13 = (t0 + 7168);
    *((int *)t13) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0296508390_3212880686_p_4(char *t0)
{
    char *t1;
    char *t2;
    int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned char t7;
    unsigned char t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    xsi_set_current_line(115, ng3);

LAB3:    t1 = (t0 + 1672U);
    t2 = *((char **)t1);
    t3 = (11 - 11);
    t4 = (t3 * -1);
    t5 = (1U * t4);
    t6 = (0 + t5);
    t1 = (t2 + t6);
    t7 = *((unsigned char *)t1);
    t8 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t7);
    t9 = (t0 + 7584);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t12 = (t11 + 56U);
    t13 = *((char **)t12);
    *((unsigned char *)t13) = t8;
    xsi_driver_first_trans_fast(t9);

LAB2:    t14 = (t0 + 7184);
    *((int *)t14) = 1;

LAB1:    return;
LAB4:    goto LAB2;

}

static void work_a_0296508390_3212880686_p_5(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    char *t9;
    unsigned int t10;
    unsigned char t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;

LAB0:    xsi_set_current_line(117, ng3);

LAB3:    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t2 = (t0 + 10872U);
    t4 = (t0 + 2632U);
    t5 = *((char **)t4);
    t4 = (t0 + 10984U);
    t6 = (t0 + 3272U);
    t7 = *((char **)t6);
    t8 = *((unsigned char *)t7);
    t6 = work_a_0296508390_3212880686_sub_3455323766_3057020925(t0, t1, t3, t2, t5, t4, t8);
    t9 = (t1 + 12U);
    t10 = *((unsigned int *)t9);
    t10 = (t10 * 1U);
    t11 = (8U != t10);
    if (t11 == 1)
        goto LAB5;

LAB6:    t12 = (t0 + 7648);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memcpy(t16, t6, 8U);
    xsi_driver_first_trans_fast(t12);

LAB2:    t17 = (t0 + 7200);
    *((int *)t17) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(8U, t10, 0);
    goto LAB6;

}

static void work_a_0296508390_3212880686_p_6(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    char *t9;
    unsigned int t10;
    unsigned char t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;

LAB0:    xsi_set_current_line(119, ng3);

LAB3:    t2 = (t0 + 1512U);
    t3 = *((char **)t2);
    t2 = (t0 + 10888U);
    t4 = (t0 + 2312U);
    t5 = *((char **)t4);
    t4 = (t0 + 10968U);
    t6 = (t0 + 3432U);
    t7 = *((char **)t6);
    t8 = *((unsigned char *)t7);
    t6 = work_a_0296508390_3212880686_sub_3455323766_3057020925(t0, t1, t3, t2, t5, t4, t8);
    t9 = (t1 + 12U);
    t10 = *((unsigned int *)t9);
    t10 = (t10 * 1U);
    t11 = (8U != t10);
    if (t11 == 1)
        goto LAB5;

LAB6:    t12 = (t0 + 7712);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memcpy(t16, t6, 8U);
    xsi_driver_first_trans_fast(t12);

LAB2:    t17 = (t0 + 7216);
    *((int *)t17) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(8U, t10, 0);
    goto LAB6;

}

static void work_a_0296508390_3212880686_p_7(char *t0)
{
    char t1[16];
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    char *t9;
    unsigned int t10;
    unsigned char t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;

LAB0:    xsi_set_current_line(121, ng3);

LAB3:    t2 = (t0 + 1672U);
    t3 = *((char **)t2);
    t2 = (t0 + 10904U);
    t4 = (t0 + 2952U);
    t5 = *((char **)t4);
    t4 = (t0 + 11000U);
    t6 = (t0 + 3272U);
    t7 = *((char **)t6);
    t8 = *((unsigned char *)t7);
    t6 = work_a_0296508390_3212880686_sub_3455323766_3057020925(t0, t1, t3, t2, t5, t4, t8);
    t9 = (t1 + 12U);
    t10 = *((unsigned int *)t9);
    t10 = (t10 * 1U);
    t11 = (12U != t10);
    if (t11 == 1)
        goto LAB5;

LAB6:    t12 = (t0 + 7776);
    t13 = (t12 + 56U);
    t14 = *((char **)t13);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    memcpy(t16, t6, 12U);
    xsi_driver_first_trans_fast(t12);

LAB2:    t17 = (t0 + 7232);
    *((int *)t17) = 1;

LAB1:    return;
LAB4:    goto LAB2;

LAB5:    xsi_size_not_matching(12U, t10, 0);
    goto LAB6;

}

static void work_a_0296508390_3212880686_p_8(char *t0)
{
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    unsigned char t9;
    unsigned char t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;

LAB0:    xsi_set_current_line(125, ng3);
    t2 = (t0 + 992U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 7248);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(126, ng3);
    t4 = (t0 + 1192U);
    t8 = *((char **)t4);
    t9 = *((unsigned char *)t8);
    t10 = (t9 == (unsigned char)3);
    if (t10 != 0)
        goto LAB8;

LAB10:
LAB9:    goto LAB3;

LAB5:    t4 = (t0 + 1032U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)3);
    t1 = t7;
    goto LAB7;

LAB8:    xsi_set_current_line(127, ng3);
    t4 = (t0 + 2472U);
    t11 = *((char **)t4);
    t4 = (t0 + 7840);
    t12 = (t4 + 56U);
    t13 = *((char **)t12);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    memcpy(t15, t11, 8U);
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(128, ng3);
    t2 = (t0 + 2792U);
    t4 = *((char **)t2);
    t2 = (t0 + 7904);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t11 = (t8 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t4, 8U);
    xsi_driver_first_trans_fast_port(t2);
    xsi_set_current_line(129, ng3);
    t2 = (t0 + 3112U);
    t4 = *((char **)t2);
    t2 = (t0 + 7968);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t11 = (t8 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t4, 12U);
    xsi_driver_first_trans_fast_port(t2);
    goto LAB9;

}


extern void work_a_0296508390_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0296508390_3212880686_p_0,(void *)work_a_0296508390_3212880686_p_1,(void *)work_a_0296508390_3212880686_p_2,(void *)work_a_0296508390_3212880686_p_3,(void *)work_a_0296508390_3212880686_p_4,(void *)work_a_0296508390_3212880686_p_5,(void *)work_a_0296508390_3212880686_p_6,(void *)work_a_0296508390_3212880686_p_7,(void *)work_a_0296508390_3212880686_p_8};
	static char *se[] = {(void *)work_a_0296508390_3212880686_sub_1303446750_3057020925,(void *)work_a_0296508390_3212880686_sub_3176558394_3057020925,(void *)work_a_0296508390_3212880686_sub_3455323766_3057020925};
	xsi_register_didat("work_a_0296508390_3212880686", "isim/cordic_tb_isim_beh.exe.sim/work/a_0296508390_3212880686.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
